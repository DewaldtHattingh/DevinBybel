---
story_id: SOL-02
title: "Salomo bou die tempel"
section: sol
pages: 6
primary_passage: "1 Kgs 5–8 (gekies)"
must_include:
  - "Bou; inwyding; wolk/heerlikheid"
theology_centre: "God woon by sy volk"
continuity_from: SOL-01
continuity_to: KIN-01
afr20_quote_check: verified
---

# Salomo bou die tempel

**Primêre gedeelte:** 1 Konings 5–8 (uitgeknip)  
**Verhaal-ID:** SOL-02

## Bladsy 1 — Opening

![Beeld: opening](../../assets/images/SOL-02-p1.png)

> **Beeldnota:** Cedarbome; timmerhout; werkers; Jerusalem op heuwel.

**Een dag, lank, lank gelede,** het koning Salomo besluit om 'n huis vir die Here te bou — 'n tempel in Jerusalem. Sy pa Dawid het al planne gemaak, maar die Here het gesê Dawid se seun sal die tempel bou. Hout van seders en cipresse het van ver gekom.

Dawid het goud en silwer versamel, maar die Here het gesê: Jy mag nie die tempel bou nie — jou seun sal dit doen. Salomo het met koning Hiram van Tyrus ooreengekom — hout van die Libanon sou kom.

---

## Bladsy 2 — Probleem

![Beeld: probleem](../../assets/images/SOL-02-p2.png)

> **Beeldnota:** Groot bouplek; klippe gestapel; jare verby.

Werkmense het jare lank geklop en gesny. Hulle het nie gehaast nie, want die Here se huis moes reg wees. Die tempel is sewe jaar lank gebou — presies soos die Here vir Dawid beveel het.

---

## Bladsy 3 — Stygende aksie

![Beeld: stygende-aksie](../../assets/images/SOL-02-p3.png)

> **Beeldnota:** Tempel struktuur neem vorm; goue besonderhede.

Hulle het die heilige plek en allerheiligste vertrek voltooi — vir die verbondsark. Goud en fyn werk vir die Here se huis. Die ark van die verbond is in die Allerheiligste gebring — die kerubs se vlerke het daaroor gesprei.

---

## Bladsy 4 — Hoofdraai

![Beeld: hoofdraai](../../assets/images/SOL-02-p4.png)

> **Beeldnota:** Ark word ingedra; priesters; wolk vul tempel.

Toe alles gereed was, het priesters die verbondsark ingedra. 'n Wolk het die tempel gevul — die Here se heerlikheid was so groot dat die priesters nie kon dien nie. Salomo het gesê: Die Here het gesê Hy sal in die donker wolk woon.

---

## Bladsy 5 — Ontknoping

![Beeld: ontknoping](../../assets/images/SOL-02-p5.png)

> **Beeldnota:** Salomo staan; hande opgehewe; bid; mense buig.

Salomo het voor die altaar gekniel en gebid: As iemand bid en na hierdie huis kyk, hoor U in die hemel. As hulle sondig en berou, vergewe U. Hy het gebid dat die Here sy oë en hart altyd hier sal wees. Israel het fees gevier — die Here woon nou in die tempel.

---

## Bladsy 6 — Geheue

![Beeld: geheue](../../assets/images/SOL-02-p6.png)

> **Beeldnota:** Klein, rustige illustrasie; tempel silhoeët en wolk.

### Wie was in hierdie verhaal?

- **Salomo** — Koning wat die tempel laat bou en dit toegewy het.
- **Priesters** — Hulle wat die verbondsark ingedra het.
- **Die Here** — Sy heerlikheid het die tempel as wolk gevul.

### Wat leer ons?

Salomo het 'n plek vir die Here gebou; die Here se heerlikheid het die tempel gevul, en Salomo het gebid dat die Here gebede sal hoor.

### Vers om te onthou

"Hoor na die gebed wat u dienaar bid." — 1 Konings 8:28. 

### Onthou jy?

1. Wie moes volgens die Here die tempel bou?
2. Wat het die tempel gevul toe die ark ingedra is?
3. Waarvoor het Salomo gebid oor mense wat bid?