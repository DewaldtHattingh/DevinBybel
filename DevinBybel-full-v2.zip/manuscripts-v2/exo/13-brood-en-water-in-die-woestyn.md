---
story_id: EXO-13
title: "Brood en water in die woestyn"
section: exo
pages: 6
primary_passage: "Exod. 16:1–35; 17:1–7"
must_include:
  - "Manna"
  - "Water uit rots"
  - "Murmureer"
theology_centre: "God voorsien"
continuity_from: EXO-12
continuity_to: EXO-14
afr20_quote_check: pending
---

# Brood en water in die woestyn

**Primêre gedeelte:** Exodus 16:1–35; 17:1–7  
**Verhaal-ID:** EXO-13

---

## Bladsy 1 — Opening

![Beeld: opening](../../assets/images/EXO-13-p1.png)

> **Beeldnota:** Woestynkamp; Israeliete lyk moeg; son breek.

**Een dag, lank, lank gelede,** het Israel in die woestyn getrek. Hulle het begin kla dat hulle nie genoeg kos het nie. Hulle het die vleispotte in Egipte onthou. Die Here het vir Moses gesê: Ek sal vir julle brood uit die hemel laat reën. Die hele gemeenskap het teen Moses en Aäron gekla in die woestyn van Sin. Hulle het die vleispotte in Egipte onthou. Die Here het gesê: Ek sal brood uit die hemel laat reën. Israel het in die woestyn van Sin gekla.

---

## Bladsy 2 — Probleem

![Beeld: probleem](../../assets/images/EXO-13-p2.png)

> **Beeldnota:** Wit korrels op grond; mense tel dit; wonder in gesigte.

Die volgende oggend lê daar wit korrels rondom die kamp. Wat is dit? het hulle gevra. Dis die brood wat die Here vir julle gegee het, het Moses gesê. Elkeen moet net genoeg vir daardie dag insamel. Sondag moet julle niks insamel nie — daar sal dubbel wees. Sommige het te veel gehou, en dit het wurms gekry. Sommige het te veel manna gehou, en dit het wurms gekry en stink. Elkeen moet net genoeg vir daardie dag insamel — twee liter per persoon. Sondag dubbel insamel.

---

## Bladsy 3 — Stygende aksie

![Beeld: stygende-aksie](../../assets/images/EXO-13-p3.png)

> **Beeldnota:** Kwartels val in kamp; families eet; sagte aand.

Die Here het ook voëls — kwartels — laat val, sodat die volk vleis gehad het. Hulle het die wit korrels manna genoem. Moses het 'n kruik vol manna voor die Here bewaar, sodat toekomstige geslagte kon sien wat God in die woestyn gegee het. So het Israel veertig jaar manna geëet. Moses het 'n kruik vol manna voor die Here bewaar vir toekomstige geslagte. Veertig jaar manna geëet.

---

## Bladsy 4 — Hoofdraai

![Beeld: hoofdraai](../../assets/images/EXO-13-p4.png)

> **Beeldnota:** Geen water; mense kla; Moses by rots.

Later het hulle by Refidim gekamp, maar daar was geen water nie. Hulle het weer gemurmureer teen Moses. Die Here het vir Moses gesê: Neem jou staf en gaan voor die volk. Ek sal voor jou staan op die rots by Horeb. Slaan op die rots, en water sal uitkom. Moses het die rots geslaan in die teenwoordigheid van die oudstes van Israel. Die Here het vir Moses gesê: Slaan op die rots by Horeb, en water sal uitkom. Water uit die rots by Horeb.

---

## Bladsy 5 — Ontknoping

![Beeld: ontknoping](../../assets/images/EXO-13-p5.png)

> **Beeldnota:** Water stroom uit rots; volk drink; rustige verligting.

En weet jy wat toe gebeur het? Moses het die rots geslaan soos die Here gesê het. Water het uitgekom, en die volk het gedrink. Moses het die plek Massa en Meriba genoem, want Israel het die Here daar getoets. Maar die Here het voorsien. Brood uit die hemel en water uit die rots. Die Here het voorsien — brood uit die hemel en water uit die rots by Refidim. Die Here het voorsien.

---

## Bladsy 6 — Geheue

![Beeld: geheue](../../assets/images/EXO-13-p6.png)

> **Beeldnota:** Klein beeld van manna en waterstroom; rustige kleure.

### Wie was in hierdie verhaal?

- **Moses** — leier wat die Here se instruksies uitgevoer het
- **Die Here** — Hy het manna, kwartels en water gegee
- **Israel** — volk wat gemurmureer en dan gevoed is

### Wat leer ons?

Selfs wanneer ons kla, voorsien God vir sy volk. Hy gee genoeg vir elke dag.

### Vers om te onthou

"Ek het vir julle brood uit die hemel laat reën, dat die volk daarvan kan eet." — Exodus 16:4 〔AFR20-kontrole〕

### Onthou jy?

1. Wat het elke oggend op die grond gele?
2. Watter reël het die Here oor Sondag gegee?
3. Waarvandaan het water vir die volk gekom?
