---
story_id: GEN-04
title: "Noag en die sondvloed"
section: gen
pages: 6
primary_passage: "Gen 6:5–8:19"
must_include:
  - "Boosheid"
  - "Noag vind guns"
  - "Ark"
  - "Diere"
  - "Vloed"
  - "God onthou Noag"
theology_centre: "Oordeel en redding"
continuity_from: GEN-03
continuity_to: GEN-05
afr20_quote_check: verified
---

# Noag en die sondvloed

**Primêre gedeelte:** Genesis 6:5–8:19  
**Verhaal-ID:** GEN-04

---

## Bladsy 1 — Opening

![Beeld: opening](../../assets/images/GEN-04-p1.png)

> **Beeldnota:** Donker wêreld; een regverdige man Noag staar na hemel — hoopvol.

**Een dag, lank, lank gelede,** was die mense se gedagtes die hele dag net kwaad. Die aarde was vol geweld. God was hartseer oor die boosheid op die aarde en het besluit om die aarde met water te reinig.

Maar Noag het guns gevind in die oë van die Here. Noag was 'n regverdige man en het naby God geleef. God het Noag genade gegee en hom vertel wat sou gebeur. Hy het vir Noag gesê: Bou 'n groot ark van goferhout. Maak kamers daarin en smeer dit binne en buite met pik.

---

## Bladsy 2 — Probleem

![Beeld: probleem](../../assets/images/GEN-04-p2.png)

> **Beeldnota:** Noag bou die lang ark; gesin help; bome en gereedschap.

Noag het die ark gebou soos God gesê het — driehonderd el lank, vyftig el wyd, dertig el hoog. 'n Deur aan die kant en drie verdiepings. Noag het jare lank gewerk, en sy seuns Sem, Gam en Jafet het hom gehelp.

God het gesê bring diere in die ark: twee van elke soort, mannetjie en wyfie, om hulle lewend te hou. Ook sewe pare van die skoon diere wat later vir offers gebruik word. Voëls en diere het na die ark gekom, soos God beveel het.

---

## Bladsy 3 — Stygende aksie

![Beeld: stygende-aksie](../../assets/images/GEN-04-p3.png)

> **Beeldnota:** Reën val; ark dryf op water; diere veilig binne — geen verdrinking sigbaar nie.

Noag, sy vrou, sy drie seuns en hulle vroue — agt mense in totaal — het die ark ingegaan. Sewe dae later het reën veertig dae en nagte geval. Waters het uit die grond opgebreek en uit die hemel gestroom. Alles onder die hemel is bedek met water.

Die ark het op die water gebly en dryf veilig. Al wat buite die ark was, het gesterf. Maar die Here het Noag onthou — Hy het nie sy dienaar vergeet nie.

---

## Bladsy 4 — Hoofdraai

![Beeld: hoofdraai](../../assets/images/GEN-04-p4.png)

> **Beeldnota:** Ark op stil water; reën stop; son breek deur wolke.

God het wind geblaas oor die aarde en die waters laat sak. Die ark het op die Araratberge tot rus gekom. Noag het 'n kraai uit die ark gestuur, maar die kraai het heen en weer bly vlieg. Toe het hy 'n duif uitgestuur. Die duif het teruggekom met 'n vars olyfblaar in sy bek. Noag het geweet die water was laag genoeg.

---

## Bladsy 5 — Ontknoping

![Beeld: ontknoping](../../assets/images/GEN-04-p5.png)

> **Beeldnota:** Noag en gesin stap uit op droë grond; diere kom uit — vreugde.

God het vir Noag gesê: Gaan uit die ark, jy en jou vrou, jou seuns en hulle vroue. Bring al die diere saam — laat hulle uitgaan en die aarde weer vul. Hulle het uitgestap op droë land.

Alles wat in die ark was, het geleef — mense, diere en voëls — net soos God beloof het. Die aarde was weer droog en stil, en die reën het opgehou.

---

## Bladsy 6 — Geheue

![Beeld: geheue](../../assets/images/GEN-04-p6.png)

> **Beeldnota:** Klein ark op droë grond met diere — rustige slot.

### Wie was in hierdie verhaal?

- **Noag** — regverdige man; het die ark gebou.
- **Noag se gesin** — vrou, seuns Sem, Gam en Jafet, en skoondogters in die ark.
- **God** — oordeel boosheid maar red wie Hy kies.

### Wat leer ons?

God straf groot boosheid, maar Hy red wie in Hom vertrou. Noag het gehoorsaam, en God het hom nie vergeet nie.

### Vers om te onthou

"Noag het guns gevind in die oë van die Here." — Genesis 6:8. 〔AFR20-kontrole〕

### Onthou jy?

1. Van watter hout moes Noag die ark bou?
2. Hoeveel diere van elke soort moes in die ark wees?
3. Hoe het Noag geweet dat die water laag genoeg was?
