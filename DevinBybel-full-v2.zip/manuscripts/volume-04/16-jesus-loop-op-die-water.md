---
story_id: V04-16
title: "Jesus loop op die water"
volume: 4
pages: 6
primary_passage: "Matt. 14:22–33"
must_include:
  - "Night"
  - "fear"
  - "It is I"
  - "Peter walks/sinks"
  - "Lord saves"
  - "worship"
deferred_to: ["V04-17"]
continuity_from: "V04-15"
continuity_to: "V04-17"
theology_centre: "Jesus is Lord over fear and the deep; faith looks to Him"
violence_note: "geen"
afr20_quote_check: pending
---

# Jesus loop op die water

**Primêre gedeelte:** Matt. 14:22–33  
**Verhaal-ID:** V04-16

---

## Bladsy 1 — Opening

![Beeld: opening](../../assets/images/V04-16-p1.png)

> **Beeldnota:** Nag op see; boot op water; dissipels roei; donker hemel; geen maan.

**Een dag, lank, lank gelede,** na Jesus die vyfduisend gevoed het, stuur hy sy dissipels in die boot. Hulle moet oorsee gaan. Jesus gaan alleen op die berg om bid. Dit is nag. Die boot is in die middel van die see. Die dissipels roei hard — die wind is teen hulle.


Na die vyfduisend stuur Jesus dissipels in die boot. Jesus gaan bid op die berg. Dit is nag. Die boot is in die middel van die see. Wind is teen hulle.

---
## Bladsy 2 — Probleem

![Beeld: probleem](../../assets/images/V04-16-p2.png)

> **Beeldnota:** Gestalte op water in verte; dissipels bang; boot klein; golwe; geen gevaar sigbaar.

In die vierde wag van die nag sien hulle Jesus loop op die see. Hulle is bang. Hulle denk dit is een spook. Hulle skree. Maar Jesus sê: Wees sterk, moenie bang wees nie. Dit is ek.

Die dissipels hoor: Dit is ek. Jesus is nie een spook nie.


In die vierde wag van die nag sien hulle Jesus loop op die see. Hulle denk dit is een spook. Hulle skree. Jesus sê: Wees sterk. Dit is ek. Moenie bang wees nie.

---
## Bladsy 3 — Stygende aksie

![Beeld: stygende-aksie](../../assets/images/V04-16-p3.png)

> **Beeldnota:** Petrus stap op water na Jesus; golwe; Petrus begin sink; Jesus naby.

Petrus sê: As dit jy is, beveel dat ek na jou kom op die water. Jesus sê: Kom. Petrus stap uit die boot en loop op die water na Jesus. Maar toe hy die wind sien, word hy bang. Hy begin sink. Hy roep: Here, red my!


Petrus sê: as dit jy is, beveel dat ek na jou kom. Jesus sê: Kom. Petrus stap op die water. Dan sien hy die wind en sink. Hy roep: Here, red my!

---
## Bladsy 4 — Hoofdraai

![Beeld: hoofdraai](../../assets/images/V04-16-p4.png)

> **Beeldnota:** Jesus gryp Petrus; hand op Petrus; water kalm word; lig van bo.

Jesus strek sy hand uit en gryp Petrus. Hy sê: Jou ongeloofige, waarom het jy gewankel? Jesus en Petrus stap in die boot. Die wind gaan weg. Die dissipels in die boot val voor Jesus neer en sê: Waarlik, jy is die Seun van God.

Hulle aanbid hom. Jesus red Petrus — en wys wie hy is.


Jesus gryp Petrus. Hulle stap in die boot. Die wind gaan weg. Die dissipels val neer: Waarlik, jy is die Seun van God. Hulle aanbid hom.

---
## Bladsy 5 — Ontknoping

![Beeld: ontknoping](../../assets/images/V04-16-p5.png)

> **Beeldnota:** Boot op kalm water; nag stil; dissipels rustig; Jesus in middel.

Die boot kom veilig by die oever. Die nag was vol bang — maar Jesus was daar. Op die water. In die boot. Die Here was by hulle.

En weet jy wat toe gebeur het? Die dissipels leer weer: Jesus is die Seun van God.


Die boot kom veilig by die oever. Die nag was bang — maar Jesus was daar. Op die water. In die boot. Die Seun van God.

---
## Bladsy 6 — Geheue

![Beeld: geheue](../../assets/images/V04-16-p6.png)

> **Beeldnota:** Klein boot op water; rustig.

### Wie was in hierdie verhaal?

- **Jesus** — loop op die water; red Petrus; wind gaan weg.
- **Petrus** — stap op water; sink; roep vir Jesus.
- **Die dissipels** — bang in die boot; aanbid Jesus.

### Wat leer ons?

Jesus is die Seun van God — selfs op die water in die nag. Wanneer ons bang word, kan ons na hom roep en hy red.

### Vers om te onthou

Wees sterk, moenie bang wees nie. Dit is ek. — Matt. 14:27. 〔AFR20-kontrole〕

### Onthou jy?

1. Wanneer sien die dissipels Jesus op die see?
2. Wat gebeur toe Petrus op die water loop?
3. Wat sê die dissipels nadat Jesus in die boot kom?

---

## Produksie-notas

- **Worteltelling (ongeveer):** narrative 410 / geheue 95 / totaal 505
- **Môre-aand-herwinning:** Lees vanaand se *Onthou jy?*-vrae môre voor die volgende storie.

