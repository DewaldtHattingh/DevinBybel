---
story_id: V02-11
title: "Die twaalf verkenners"
volume: 2
pages: 6
primary_passage: "Num. 13–14"
must_include:
  - "Twaalf spioene"
  - "Druif"
  - "Tien vreesagtige verslae"
  - "Kaleb/Josua vertrou"
  - "Oordel van swerwing"
  - "Barmhartigheid vir kinders"
deferred_to: ["V02-12"]
continuity_from: "V02-10"
continuity_to: "V02-12"
theology_centre: "Vertroue op God bring lewe; vrees bring straf"
violence_note: "straf genoem; geen grafiese detail"
afr20_quote_check: pending
---

# Die twaalf verkenners

**Primêre gedeelte:** Numeri 13–14  
**Verhaal-ID:** V02-11

---

## Bladsy 1 — Opening

![Beeld: opening](../../assets/images/V02-11-p1.png)

> **Beeldnota:** Twaalf manne vertrek; Kanaän in die verte; son.

**Een dag, lank, lank gelede,** het die Here vir Moses gesê: Stuur manne om die land Kanaän te verken — een uit elke stam, twaalf in totaal. Hulle het veertig dae deur die land gegaan. Die land was ryk — met druiwe so groot dat twee man dit op ’n stok moes dra. Die Here het een man uit elke stam gestuur. Hulle het druiwe van Eskol meegebring — so groot dat twee man dit op ’n stok moes dra.

---

## Bladsy 2 — Probleem

![Beeld: probleem](../../assets/images/V02-11-p2.png)

> **Beeldnota:** Tien manne praat bang; volk luister bekommerd; groot druif tafel.

Toe die twaalf teruggekom het, het tien van hulle gesê: Die land is goed, maar die mense is sterk. Ons lyk soos sprinkane voor hulle. Die volk het bang geword en gekla. Laat ons liewer ’n leier kies en teruggaan na Egipte, het hulle gesê. Hulle het gesê die land vloei oor van melk en hening, maar die mense is sterk en die stede versterk. Die volk het die hele nag gehuil.

---

## Bladsy 3 — Stygende aksie

![Beeld: stygende-aksie](../../assets/images/V02-11-p3.png)

> **Beeldnota:** Kaleb en Josua staan vorentoe; volk luister; ernstige oomblik.

Maar Kaleb en Josua het die volk laat stil word. As die Here welbehae aan ons het, sal Hy ons inbring, het hulle gesê. Moenie rebelleer teen die Here nie. Die volk wou hulle met klippe gooi. Die Here se heerlikheid het by die tent verskyn. Kaleb het gesê: Ons moet dadelik optrek en die land inpak. Moenie bang wees vir die mense van die land nie. Die volk wou hulle met klippe gooi.

---

## Bladsy 4 — Hoofdraai

![Beeld: hoofdraai](../../assets/images/V02-11-p4.png)

> **Beeldnota:** Moses bid; Here praat; donker wolk; ernstig.

Die Here het gesê: Hulle sal veertig jaar in die woestyn rondswerf — een jaar vir elke dag van verkenning. Hierdie geslag sal nie die land inkom nie. Maar Kaleb en Josua — die wat My welbehae gehad het — sal die land sien. Kinders wat hulle nie geken het nie, sal wel inkom. Almal van twintig jaar en ouer sou in die woestyn sterf. Net Kaleb en Josua — en die kinders — sou die beloofde land sien.

---

## Bladsy 5 — Ontknoping

![Beeld: ontknoping](../../assets/images/V02-11-p5.png)

> **Beeldnota:** Volk treur; Kaleb en Josua staan stewig; sagte aand.

En weet jy wat toe gebeur het? Die volk het die volgende oggend spijt gekry en probeer opgaan. Maar die Here was nie by hulle nie. Hulle is teruggedryf. Israel sou veertig jaar in die woestyn swerf. Maar die Here het barmhartigheid gehou vir die kinders en vir die wat op Hom vertrou het. Die Amalekiete en Kanaäniete het hulle teruggedryf toe hulle sonder die Here probeer opgaan het. Israel sou veertig jaar swerf.

---

## Bladsy 6 — Geheue

![Beeld: geheue](../../assets/images/V02-11-p6.png)

> **Beeldnota:** Klein beeld van druifstok; rustige kleure.

### Wie was in hierdie verhaal?

- **Moses** — leier wat die verkenners gestuur het
- **Kaleb** — man wat gesê het ons kan die land inpak
- **Josua** — man wat saam met Kaleb vertrou het
- **Tien verkenners** — manne wat bang verslae gebring het
- **Die Here** — Hy het oordeel en barmhartigheid gegee

### Wat leer ons?

Wanneer ons op God vertrou, kan ons Hom volg selfs wanneer dinge moeilik lyk. Vrees sonder vertroue lei weg van God se belofte.

### Vers om te onthou

“As die Here welbehae aan ons het, dan sal Hy ons inbring in hierdie land en dit aan ons gee.” — Numeri 14:8 〔AFR20-kontrole〕

### Onthou jy?

1. Hoeveel verkenners het die land Kanaän verken?
2. Wat het Kaleb en Josua gesê?
3. Wie sou wel die beloofde land binnegaan?

---

## Produksie-notas

- **Worteltelling (ongeveer):** narratief 440 / geheue 125 / totaal 565
- **Môre-aand-herwinning:** Lees vanaand se *Onthou jy?*-vrae môre voor die volgende storie.
